const Events = () => {
  return (
    <section id="events" className="min-h-screen py-20 px-8">
      <div className="max-w-6xl mx-auto">
        <h2 className="mb-16 text-center">Upcoming Events</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <div key={i} className="border border-medium-gray p-6 hover:border-accent-red transition">
              <div className="mb-4 text-light-gray">Event {i}</div>
              <h3 className="mb-2">TBA</h3>
              <p className="text-sm text-light-gray mb-4">Coming soon...</p>
              <button className="text-accent-red hover:text-red-500 transition text-sm font-semibold">More Info →</button>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
export default Events;
