const Agency = () => {
  return (
    <section id="agency" className="min-h-screen py-20 px-8 bg-dark-gray/50">
      <div className="max-w-6xl mx-auto">
        <h2 className="mb-16 text-center">About 3H33</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div><h3 className="mb-4 text-accent-red">Artist Management</h3><p>We represent and develop the careers of emerging and established electronic music artists. Strategic guidance, career development, and industry connections.</p></div>
          <div><h3 className="mb-4 text-accent-red">Booking Services</h3><p>Premium booking for festivals, clubs, and events worldwide. Direct access to top-tier venues and curated event opportunities for our roster artists.</p></div>
        </div>
      </div>
    </section>
  );
};
export default Agency;
