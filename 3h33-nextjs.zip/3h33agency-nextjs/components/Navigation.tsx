import Link from 'next/link';
const Navigation = () => {
  return (
    <nav className="fixed top-0 left-0 right-0 z-50 flex items-center justify-between px-8 py-6 bg-black/20 backdrop-blur-sm">
      <div className="text-2xl font-bold">3H33</div>
      <div className="flex gap-8">
        <Link href="#artists" className="hover:text-accent-red transition">Artists</Link>
        <Link href="#agency" className="hover:text-accent-red transition">Agency</Link>
        <Link href="#contact" className="hover:text-accent-red transition">Contact</Link>
      </div>
    </nav>
  );
};
export default Navigation;
