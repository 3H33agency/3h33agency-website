import artists from '@/data/artists.json';
const Artists = () => {
  return (
    <section id="artists" className="min-h-screen py-20 px-8">
      <div className="max-w-6xl mx-auto">
        <h2 className="mb-16 text-center">Our Artists</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {artists.map((artist) => (
            <div key={artist.id} className="group cursor-pointer">
              <div className="overflow-hidden bg-dark-gray aspect-square mb-4 hover:scale-105 transition duration-300">
                <div className="w-full h-full bg-medium-gray flex items-center justify-center">
                  <span className="text-light-gray">{artist.name}</span>
                </div>
              </div>
              <h3>{artist.name}</h3>
              <p className="text-sm text-light-gray">{artist.title}</p>
              <p className="text-xs text-medium-gray mt-2">{artist.location} • {artist.genre}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
export default Artists;
