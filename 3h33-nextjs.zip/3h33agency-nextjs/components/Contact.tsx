const Contact = () => {
  return (
    <section id="contact" className="min-h-screen py-20 px-8 bg-dark-gray/50 flex items-center justify-center">
      <div className="max-w-2xl mx-auto text-center">
        <h2 className="mb-8">Get In Touch</h2>
        <p className="text-lg mb-8 text-light-gray">Interested in booking or collaborating with our artists? Let's talk.</p>
        <a href="mailto:contact@3h33agency.fr" className="inline-block px-8 py-3 bg-accent-red hover:bg-red-700 text-white font-semibold transition">contact@3h33agency.fr</a>
      </div>
    </section>
  );
};
export default Contact;
