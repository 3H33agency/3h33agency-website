const Hero = () => {
  return (
    <section className="min-h-screen flex items-center justify-center px-8">
      <div className="text-center max-w-4xl">
        <h1 className="mb-6">Management & Booking<span className="text-accent-red"> Electronic Music</span></h1>
        <p className="text-lg mb-8 text-light-gray">Your gateway to underground electronic music excellence. Premier artist management and booking for the most innovative producers and DJs.</p>
        <button className="px-8 py-3 bg-accent-red hover:bg-red-700 text-white font-semibold transition">Get In Touch</button>
      </div>
    </section>
  );
};
export default Hero;
