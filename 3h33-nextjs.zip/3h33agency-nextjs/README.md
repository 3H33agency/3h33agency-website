# 3H33 Agency - Next.js Redesign

Premium artist management and booking for electronic music.

## Installation & Deployment

1. Extract this ZIP into your 3h33agency folder
2. Run: `git add . && git commit -m "refonte: Next.js 14" && git push`
3. Vercel will automatically deploy!
