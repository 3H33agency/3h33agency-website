import Stars from "@/components/Stars";
import Navigation from "@/components/Navigation";
import Hero from "@/components/Hero";
import Artists from "@/components/Artists";
import Agency from "@/components/Agency";
import Events from "@/components/Events";
import Contact from "@/components/Contact";
export default function Home() {
  return (
    <div className="bg-black min-h-screen">
      <Stars />
      <Navigation />
      <Hero />
      <Artists />
      <Agency />
      <Events />
      <Contact />
    </div>
  );
}
