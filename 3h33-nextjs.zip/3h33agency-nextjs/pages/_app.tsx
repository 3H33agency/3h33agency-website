import "@/styles/globals.css";
import type { AppProps } from "next/app";
import { useEffect } from "react";
import Lenis from "lenis";
export default function App({ Component, pageProps }: AppProps) {
  useEffect(() => {
    const lenis = new Lenis({ lerp: 0.1, duration: 1.2 });
    const raf = (time: number) => {
      lenis.raf(time);
      requestAnimationFrame(raf);
    };
    requestAnimationFrame(raf);
    return () => lenis.destroy();
  }, []);
  return <Component {...pageProps} />;
}
